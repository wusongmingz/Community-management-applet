package com.zqg.communityManagementBackend.dto;

import lombok.Data;

/**
 * @author lunaryoung
 */
@Data
public class Page {
    private int startPage;
    private int pageSize;
}
