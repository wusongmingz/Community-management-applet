package com.zqg.communityManagementBackend.entity;

import lombok.Data;

/**
 * @creteTime: 2022/2/21 2:58
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
@Data
public class Pie {
    private Integer value;
    private String name;
}
