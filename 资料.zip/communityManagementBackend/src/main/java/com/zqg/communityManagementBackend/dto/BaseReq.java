package com.zqg.communityManagementBackend.dto;

/**
 * @creteTime: 2021/12/30 11:22
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
public class BaseReq {
}
