package com.zqg.communityManagementBackend.dto;

import lombok.Data;

/**
 * @creteTime: 2021/12/30 11:23
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */

@Data
public class BaseRsp {
    private Integer code;
    private String msg;
}
