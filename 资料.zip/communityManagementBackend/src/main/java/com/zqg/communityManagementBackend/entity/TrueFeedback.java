package com.zqg.communityManagementBackend.entity;

import lombok.Data;

@Data
public class TrueFeedback {
    private Integer id;
    private String time;
    private String content;
}
