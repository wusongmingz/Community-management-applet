package com.zqg.communityManagementBackend.dto.response;

import com.zqg.communityManagementBackend.dto.request.ArticleReq;
import lombok.Data;

/**
 * @creteTime: 2022/2/18 16:21
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
@Data
public class AppViewArticleRsp {
    private ArticleReq date;
}
