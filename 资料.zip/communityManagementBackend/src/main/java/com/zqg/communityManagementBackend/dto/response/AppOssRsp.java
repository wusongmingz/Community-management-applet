package com.zqg.communityManagementBackend.dto.response;

import lombok.Data;

/**
 * @creteTime: 2022/2/19 19:50
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
@Data
public class AppOssRsp {
    private String url;
    private String name;
}
