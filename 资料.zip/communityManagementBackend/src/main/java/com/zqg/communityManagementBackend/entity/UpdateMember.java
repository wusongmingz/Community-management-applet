package com.zqg.communityManagementBackend.entity;

import lombok.Data;

/**
 * @creteTime: 2022/2/16 18:38
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
@Data
public class UpdateMember {
    private Integer id;
    private String position;
}
