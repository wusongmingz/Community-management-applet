package com.zqg.communityManagementBackend.dto.request;

import lombok.Data;

/**
 * @creteTime: 2022/2/17 7:16
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
@Data
public class ApplyUpdateStatus {
    private Integer id;
    private String status;
}
