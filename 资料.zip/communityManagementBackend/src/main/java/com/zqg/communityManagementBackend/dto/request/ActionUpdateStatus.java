package com.zqg.communityManagementBackend.dto.request;

import lombok.Data;

/**
 * @creteTime: 2022/2/17 14:20
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
@Data
public class ActionUpdateStatus {
    private Integer id;
    private String status;
}
