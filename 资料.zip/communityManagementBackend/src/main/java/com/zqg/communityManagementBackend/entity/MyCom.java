package com.zqg.communityManagementBackend.entity;

import lombok.Data;

/**
 * @creteTime: 2022/1/10 10:26
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
@Data
public class MyCom {
    private String openId;
    private String association;
    private String position;
}
