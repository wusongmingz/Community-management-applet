package com.zqg.communityManagementBackend.dto.response;

import com.zqg.communityManagementBackend.dto.BaseRsp;
import lombok.Data;

/**
 * @creteTime: 2022/2/18 7:10
 * @author: lunarYoung
 * @version: v 1.0
 * @Description:
 */
@Data
public class VieArticleRsp extends BaseRsp {
    private String content;
}
